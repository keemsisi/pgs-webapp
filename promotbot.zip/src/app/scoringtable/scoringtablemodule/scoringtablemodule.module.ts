import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ScoringtablemoduleRoutingModule } from './scoringtablemodule-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ScoringtablemoduleRoutingModule
  ]
})
export class ScoringtablemoduleModule { }
