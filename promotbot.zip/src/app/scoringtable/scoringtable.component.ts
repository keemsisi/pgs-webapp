import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scoringtable',
  templateUrl: './scoringtable.component.html',
  styleUrls: ['./scoringtable.component.scss']
})
export class ScoringtableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
