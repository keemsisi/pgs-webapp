import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountactivationmoduleRoutingModule } from './accountactivationmodule-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AccountactivationmoduleRoutingModule
  ]
})
export class AccountactivationmoduleModule { }
