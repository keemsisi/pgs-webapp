import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PreviewCvModRoutingModule } from './preview-cv-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PreviewCvModRoutingModule
  ]
})
export class PreviewCvModModule { }
