import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-administrator',
  templateUrl: './contact-administrator.component.html',
  styleUrls: ['./contact-administrator.component.css']
})
export class ContactAdministratorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
