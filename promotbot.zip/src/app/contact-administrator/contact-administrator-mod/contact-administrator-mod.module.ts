import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactAdministratorModRoutingModule } from './contact-administrator-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ContactAdministratorModRoutingModule
  ]
})
export class ContactAdministratorModModule { }
