import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-account-login',
  templateUrl: './cv-account-login.component.html',
  styleUrls: ['./cv-account-login.component.css']
})
export class CvAccountLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
