import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CvAccountLoginModRoutingModule } from './cv-account-login-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CvAccountLoginModRoutingModule
  ]
})
export class CvAccountLoginModModule { }
