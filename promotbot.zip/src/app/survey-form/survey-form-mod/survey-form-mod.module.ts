import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SurveyFormModRoutingModule } from './survey-form-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SurveyFormModRoutingModule
  ]
})
export class SurveyFormModModule { }
