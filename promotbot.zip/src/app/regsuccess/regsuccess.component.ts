import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regsuccess',
  templateUrl: './regsuccess.component.html',
  styleUrls: ['./regsuccess.component.scss']
})
export class RegsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
