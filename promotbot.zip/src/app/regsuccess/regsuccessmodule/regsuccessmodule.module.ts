import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegsuccessmoduleRoutingModule } from './regsuccessmodule-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RegsuccessmoduleRoutingModule
  ]
})
export class RegsuccessmoduleModule { }
