import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForgotPaswwordRoutingModule } from './forgot-password-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ForgotPaswwordRoutingModule
  ]
})
export class ForgotPasswordModule { }