import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminModRoutingModule } from './admin-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AdminModRoutingModule
  ]
})
export class AdminModModule { }
