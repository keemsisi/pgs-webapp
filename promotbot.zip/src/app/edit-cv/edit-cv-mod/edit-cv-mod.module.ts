import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditCvModRoutingModule } from './edit-cv-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EditCvModRoutingModule
  ]
})
export class EditCvModModule { }
