import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pgs-header',
  templateUrl: './pgs-header.component.html',
  styleUrls: ['./pgs-header.component.css']
})
export class PgsHeaderComponent implements OnInit {

  
  constructor() { }

  ngOnInit() {
  }

}
