import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CvDocumentationStageModRoutingModule } from './cv-documentation-stage-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CvDocumentationStageModRoutingModule
  ]
})
export class CvDocumentationStageModModule { }
