import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-documentation-stage',
  templateUrl: './cv-documentation-stage.component.html',
  styleUrls: ['./cv-documentation-stage.component.css']
})
export class CvDocumentationStageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
