import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagenotfoundModRoutingModule } from './pagenotfound-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PagenotfoundModRoutingModule
  ]
})
export class PagenotfoundModModule { }
