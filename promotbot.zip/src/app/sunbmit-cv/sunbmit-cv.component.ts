import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sunbmit-cv',
  templateUrl: './sunbmit-cv.component.html',
  styleUrls: ['./sunbmit-cv.component.scss']
})
export class SunbmitCvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
