import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PgsHomeLandingModRoutingModule } from './pgs-home-landing-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PgsHomeLandingModRoutingModule
  ]
})
export class PgsHomeLandingModModule {}
