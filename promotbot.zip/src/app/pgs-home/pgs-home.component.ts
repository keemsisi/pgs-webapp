import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pgs-home',
  templateUrl: './pgs-home.component.html',
  styleUrls: ['./pgs-home.component.css']
})
export class PGSHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
