import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountDashboardModRoutingModule } from './account-dashboard-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AccountDashboardModRoutingModule
  ]
})
export class AccountDashboardModModule { }
