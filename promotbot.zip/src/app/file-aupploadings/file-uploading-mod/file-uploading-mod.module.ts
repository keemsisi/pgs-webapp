import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FileUploadingModRoutingModule } from './file-uploading-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FileUploadingModRoutingModule
  ]
})
export class FileUploadingModModule { }
