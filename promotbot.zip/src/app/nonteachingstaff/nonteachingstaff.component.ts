import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nonteachingstaff',
  templateUrl: './nonteachingstaff.component.html',
  styleUrls: ['./nonteachingstaff.component.scss']
})
export class NonteachingstaffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
