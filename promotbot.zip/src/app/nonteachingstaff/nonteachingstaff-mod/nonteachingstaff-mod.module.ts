import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NonteachingstaffModRoutingModule } from './nonteachingstaff-mod-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NonteachingstaffModRoutingModule
  ]
})
export class NonteachingstaffModModule { }
