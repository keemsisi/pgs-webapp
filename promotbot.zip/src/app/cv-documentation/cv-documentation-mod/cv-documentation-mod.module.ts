import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CvDocumentationModRoutingModule } from './cv-documentation-mod-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CvDocumentationModRoutingModule
  ]
})
export class CvDocumentationModModule { }