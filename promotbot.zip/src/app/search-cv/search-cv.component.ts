import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-cv',
  templateUrl: './search-cv.component.html',
  styleUrls: ['./search-cv.component.css']
})
export class SearchCvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
