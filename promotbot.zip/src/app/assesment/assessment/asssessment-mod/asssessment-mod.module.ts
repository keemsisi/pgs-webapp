import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AsssessmentModRoutingModule } from './asssessment-mod-routing.module';
import { AssesmentComponent } from '../../assesment.component';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AsssessmentModRoutingModule
  ]
})
export class AsssessmentModModule { }
